"use strict";
/*global $ */


/*http://stackoverflow.com/questions/11930253/how-to-create-a-login-page-when-username-and-password-is-equal-in-html als bron */

function check(form) {
					/*Checkt of de code hetzelfde is als wat je invult om verder te kunnen gaan*/
					if (form.userid.value == "manon" && form.pswrd.value == "secret") {
						window.open("#site"); /*site openen*/
						window.close(); /*login tab sluiten*/
					} 
					else {
						alert("Er is of geen wachtwoord of username gegeven.") /*fout tonen*/
					}
}

var dairy, teller, tText, db, title, datum, tekst;


//Databank is gemaakt aan de hand van de les 8, de voorbeelden die we gekregen hebben.

function updateTables() {
	teller = 0;
	tText = "";
	for (teller = 0; teller < dairy.length; teller += 1) {
		tText += "<tr><td>" + dairy[teller].title + "<\/td><td>" + dairy[teller].datum + "<\/td><td>" + dairy[teller].tekst + "<\/td><\/tr>";
	}
	$("#dairy tbody").html(tText);
}

function toonverhaal() {
		window.open("#toonverhaal");		
}

function updateTablesSQL() {
	db.transaction(function (tx) {
		tx.executeSql('SELECT * FROM dairy order by datum desc', [], function (tx, results) {
			var len = results.rows.length,
				i;
			tText = "";
			for (teller = 0; teller < len; teller += 1) {
				tText += "<tr><td>" + results.rows.item(teller).title + "<\/td><td id='grote'>" + results.rows.item(teller).datum + "<\/td><td><a  href='#toonVerhaal' onclick='toonVerhaal("+teller+");><p id='scroll'>" + results.rows.item(teller).tekst + "</p></a><\/td><\/tr>";
				//<a  href='#toonVerhaal' onclick='toonVerhaal("+teller+");'> 
			}
			$("#dairyTabelDB tbody").html(tText);

		}, null);
	});

}

$(document).ready(function () {
	
	$("input[required]").after(" * verplicht in te vullen");
	$("textarea[required]").after(" * verplicht in te vullen");

	$("#index").click(function () {
		$("#dagboek").slideUp("slow");
		$("#lijst").slideUp("slow");
		$("#home").slideDown("slow");
	});

	$("#new").click(function () {
		$("#home").slideUp("slow");
		$("#lijst").slideUp("slow");
		$("#dagboek").slideDown("slow");
	});

	$("#list").click(function () {
		$("#dagboek").slideUp("slow");
		$("#home").slideUp("slow");
		$("#lijst").slideDown("slow");
	});
	
	title = "Voorbeeld";
	datum = '01/11/2016';
	tekst = "Liefste Dagboek, ...";


	dairy = [{
		"title": title,
		"datum": datum,
		"tekst": tekst
				}];

	// schakel de transities uit
	$(document).bind('pageinit', function () {
		$.mobile.defaultPageTransition = 'none';
	});

	// open de databank
	db = openDatabase('mydb', '1.0', 'Test DB', 0.1 * 1024 * 1024);

	db.transaction(function (tx) {
		tx.executeSql('CREATE TABLE IF NOT EXISTS dairy (title, datum, tekst)');
		//where title= ? and datum= ? and tekst = ?
		tx.executeSql('select count(*) as aantal from dairy', [], function (tx, results) {
			// kijk na of het resultaat ok is.
			console.log("select werkt");
			if (results.rows.item(0).aantal === 0) {
				// er was nog geen combinatie met de title & datum in de db, dus voeg die nu toe :
				tx.executeSql('INSERT INTO dairy (title,datum,tekst) VALUES (?, ?, ?)', [title, datum, tekst], function (tx, results) {
					console.log("ok!");
				}, function (tx, error) {
					console.log("NOK!");
				});
				
			}

		}, function (tx, error) {
			console.log("NOK!");
		});
		updateTablesSQL();
	});

	//updateTables();
	updateTablesSQL();

	$("#voegToe").click(function () {
		title = $("#titleDairy").val();
		datum = $("#datumDairy").val();
		tekst = $("#tekstDairy").val();
		dairy.push({
			"title": title,
			"datum": datum,
			"tekst": tekst
		});

		db.transaction(function (tx) {
			tx.executeSql('INSERT INTO dairy (title,datum,tekst) VALUES (?, ?, ?)', [title, datum, tekst]);
		});
		//updateTables();
		updateTablesSQL();

	});
});