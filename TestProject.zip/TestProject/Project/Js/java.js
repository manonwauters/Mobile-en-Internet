"use strict";
/*global $ */
var dairy, teller, tText, db, title, datum, tekst;

function updateTables() {
	teller = 0;
	tText = "";
	for (teller = 0; teller < dairy.length; teller += 1) {
		tText += "<tr><td>" + dairy[teller].title + "<\/td><td>" + dairy[teller].datum + "<\/td><\/tr>" + dairy[teller].tekst + "<\/td><\/tr>";
	}
	$("#dairy tbody").html(tText);
}

function updateTablesSQL() {
	db.transaction(function (tx) {
		tx.executeSql('SELECT * FROM dairys order by datum desc', [], function (tx, results) {
			var len = results.rows.length,
				i;
			tText = "";
			for (teller = 0; teller < len; teller += 1) {
				tText += "<tr><td>" + results.rows.item(teller).title + "<\/td><td>" + results.rows.item(teller).datum + "<\/td><\/tr>" + results.rows.item(teller).tekst + "<\/td><\/tr>";
			}
			$("#dairyDB tbody").html(tText);

		}, null);
	});

}

$(document).ready(function () {
	
	$("input[required]").after(" * verplicht in te vullen");
	$("textarea[required]").after(" * verplicht in te vullen");

	$("#index").click(function () {
		$("#dagboek").slideUp("slow");
		$("#lijst").slideUp("slow");
		$("#home").slideDown("slow");
	});

	$("#new").click(function () {
		$("#home").slideUp("slow");
		$("#lijst").slideUp("slow");
		$("#dagboek").slideDown("slow");
	});

	$("#list").click(function () {
		$("#dagboek").slideUp("slow");
		$("#home").slideUp("slow");
		$("#lijst").slideDown("slow");
	});
	
	title = "Voorbeeld";
	datum = '01/11/2016';
	tekst = "Liefste Dagboek, ...";


	dairy = [{
		"title": title,
		"datum": datum,
		"tekst": tekst
				}];

	// schakel de transities uit
	$(document).bind('pageinit', function () {
		$.mobile.defaultPageTransition = 'none';
	});

	// open de databank
	db = openDatabase('mydb', '1.0', 'Test DB', 0.1 * 1024 * 1024 * 1024);

	db.transaction(function (tx) {
		tx.executeSql('CREATE TABLE IF NOT EXISTS dairy (title, datum,tekst)');
		//where title= ? and datum= ? and tekst = ?
		tx.executeSql('select count(*) as aantal from dairys where title like ? and datum like ? and tekst like ?', [title, datum, tekst], function (tx, results) {
			// kijk na of het resultaat ok is.
			console.log("select werkt");
			if (results.rows.item(0).aantal === 0) {
				// er was nog geen combinatie met de title & datum in de db, dus voeg die nu toe :
				tx.executeSql('INSERT INTO dairys (title,datum,tekst) VALUES (?, ?)', [title, datum, tekst], function (tx, results) {
					console.log("ok!");
				}, function (tx, error) {
					console.log("NOK!");
				});
			}

		}, function (tx, error) {
			console.log("NOK!");
		});
	});

	updateTables();
	updateTablesSQL();

	$("#voegToe").click(function () {
		title = $("#titleDairy").val();
		datum = parseFloat($("#datumDairy").val());
		tekst = parseFloat($("#tekstDairy").val());
		dairy.push({
			"title": title,
			"datum": datum,
			"tekst": tekst
		});

		db.transaction(function (tx) {
			tx.executeSql('INSERT INTO dairys (title,datum,tekst) VALUES (?, ?, ?)', [title, datum, tekst]);
		});
		updateTables();
		updateTablesSQL();

	});
});